<?php

namespace WebPortalBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class WebPortalBundle extends Bundle
{
}
